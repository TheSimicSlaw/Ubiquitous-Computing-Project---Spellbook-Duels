//
//  NewDeckPopupView.swift
//  Spellbook Duels
//
//  Created by Ryan Camp on 11/9/25.
//

//import SwiftUI
//
//struct NewDeckPopupView<PopupContent>: ViewModifier where PopupContent: View {
//    
//    init(isPresented: Binding<Bool>, view: @escaping () -> PopupContent) {
//        self._isPresented = isPresented
//        self.view = view
//    }
//    
//    @Binding var isPresented: Bool
//    
//    var view: () -> PopupContent
//    
////    var body: some View {
////        
////    }
//}

//#Preview {
//    NewDeckPopupView()
//}
