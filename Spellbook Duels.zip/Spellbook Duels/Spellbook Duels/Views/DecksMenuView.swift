//
//  DecksMenuView.swift
//  Spellbook Duels
//
//  Created by Ryan Camp on 10/3/25.
//

import SwiftUI
import SwiftData

struct DecksMenuView: View {
    @Query var decks: [DeckListModel]
    
    @State private var path = NavigationPath()
    @State private var selectedDeck: DeckListModel? = nil
    
    @State private var askingNewDeckDetails = false
    
    let columns = [GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                Color("MenuBackgroundColor").ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Rectangle()
                            .fill(Color("AccentTwo"))
                            .frame(width:425, height:190)
                            .ignoresSafeArea()
                        
                        Text("Decks")
                            .font(.custom( "InknutAntiqua-Regular", size: 50.0))
                            .bold()
                            .padding(.bottom, 50)
                        
                    }
                    
                    Spacer()
                    
                    
                    ScrollView {
                        LazyVGrid (columns: columns) {
                            ForEach(decks) { deck in
                                Button {
                                    selectedDeck = deck
                                    path.append(deck)
                                } label: {
                                    ZStack {
                                        VStack {
                                            Spacer(minLength: 20)
                                            
                                            DeckGridIconView(colors: [ElementColorDict.elementColors[deck.deckElements[0]]!, ElementColorDict.elementColors[deck.deckElements[1]]!])
                                            
                                            Text(deck.deckName)
                                                .font(.custom( "InknutAntiqua-Regular", size: 19.0))
                                                .foregroundStyle(.black)
                                                .lineLimit(nil)
                                                .fixedSize(horizontal: false, vertical: true)
                                                .padding(10)
                                        }
                                        .frame(width: 200, height: .infinity)
                                        .background(Color("AccentOne"))
                                        .padding(.vertical, 0.5)
                                    }
                                }
                            }
                            Button {
                                askingNewDeckDetails = true
                                //newDeck = DeckListModel(deckname: "", cardList: [], cardCounts: [], deckElements: <#T##[Element]#>)
                            } label: {
                                Image(systemName: "plus")
                                    .resizable()
                                    .scaledToFit()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(25)
                                    .foregroundStyle(.black)
                                    .frame(width:200, height:300)
                                    .background(RoundedRectangle(cornerRadius: 10).fill(Color("AccentOne")))
                                    
                            }
                        }
                    }
                }
                .navigationDestination(for: DeckListModel.self) { selecteddeck in
                    DeckEditorView(deck: selecteddeck)
                }
            }
        }
        
    }
}

//extension View {
//    public func newDeckPopup<PopupContent: View>(
//        isPresented: Binding<Bool>,
//        view: @escaping () -> PopupContent
//    ) -> some View {
//        self.modifier(
//            NewDeckPopupView(isPresented: isPresented, view: view)
//        )
//    }
//}

#Preview {
    DecksMenuView()
        .modelContainer(DeckListModel.precons)
}
